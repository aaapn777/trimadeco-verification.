export default function handler(_request, response) {
  const siteKey = process.env.TURNSTILE_SITE_KEY;
  if (!siteKey) {
    return response.status(500).json({ error: "TURNSTILE_SITE_KEY no está configurada." });
  }
  response.setHeader("Cache-Control", "no-store");
  return response.status(200).json({ siteKey });
}
