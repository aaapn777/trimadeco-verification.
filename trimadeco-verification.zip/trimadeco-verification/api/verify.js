export default async function handler(request, response) {
  if (request.method !== "POST") {
    response.setHeader("Allow", "POST");
    return response.status(405).json({ success: false, error: "Método no permitido." });
  }

  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    return response.status(500).json({ success: false, error: "Falta configurar TURNSTILE_SECRET_KEY." });
  }

  const token = request.body?.token;
  if (typeof token !== "string" || !token) {
    return response.status(400).json({ success: false, error: "Token de verificación faltante." });
  }

  try {
    const formData = new URLSearchParams();
    formData.append("secret", secret);
    formData.append("response", token);
    if (request.headers["x-forwarded-for"]) {
      formData.append("remoteip", request.headers["x-forwarded-for"].split(",")[0].trim());
    }

    const validation = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: formData
    });
    const result = await validation.json();

    if (!result.success) {
      return response.status(403).json({ success: false, error: "Verificación no válida." });
    }

    return response.status(200).json({ success: true });
  } catch (_error) {
    return response.status(502).json({ success: false, error: "No se pudo contactar el servicio de verificación." });
  }
}
